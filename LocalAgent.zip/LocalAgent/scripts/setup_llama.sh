#!/usr/bin/env bash
# Скачивает фиксированную версию llama.cpp, под которую написан JNI-код (app/src/main/cpp/llm_jni.cpp).
set -euo pipefail
TAG="b8999"
DEST="$(cd "$(dirname "$0")/.." && pwd)/app/src/main/cpp/llama.cpp"
if [ -f "$DEST/CMakeLists.txt" ]; then
  echo "llama.cpp уже на месте: $DEST"
  exit 0
fi
git clone --depth 1 --branch "$TAG" https://github.com/ggml-org/llama.cpp "$DEST"
rm -rf "$DEST/.git"
echo "llama.cpp $TAG готов"

// JNI-мост к llama.cpp. API сверен с llama.cpp b8999 (см. scripts/setup_llama.sh).
#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <exception>
#include <mutex>
#include <string>
#include <vector>

#include "llama.h"

#define TAG "LocalAgentLLM"
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

static llama_model *g_model = nullptr;
static llama_context *g_ctx = nullptr;
static const llama_vocab *g_vocab = nullptr;
static std::atomic<bool> g_stop{false};
static std::mutex g_mutex;
static bool g_backend_ready = false;

static void log_cb(ggml_log_level level, const char *text, void *) {
    if (level >= GGML_LOG_LEVEL_WARN) LOGW("%s", text);
}

// Разбирает байты UTF-8: корректные последовательности переводит в UTF-16,
// неполный хвост оставляет в `pending` до следующего токена, мусорные байты отбрасывает.
static std::u16string drain_utf8(std::string &pending) {
    std::u16string out;
    size_t i = 0, n = pending.size();
    while (i < n) {
        unsigned char c = (unsigned char) pending[i];
        size_t len = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 0;
        if (len == 0) { i++; continue; }
        if (i + len > n) break;  // неполная последовательность — ждём продолжения
        bool ok = true;
        for (size_t k = 1; k < len; k++) {
            if ((((unsigned char) pending[i + k]) & 0xC0) != 0x80) { ok = false; break; }
        }
        if (!ok) { i++; continue; }
        uint32_t cp;
        if (len == 1) cp = c;
        else if (len == 2) cp = c & 0x1F;
        else if (len == 3) cp = c & 0x0F;
        else cp = c & 0x07;
        for (size_t k = 1; k < len; k++) cp = (cp << 6) | (((unsigned char) pending[i + k]) & 0x3F);
        if (cp >= 0x10000) {
            cp -= 0x10000;
            out.push_back((char16_t) (0xD800 + (cp >> 10)));
            out.push_back((char16_t) (0xDC00 + (cp & 0x3FF)));
        } else {
            out.push_back((char16_t) cp);
        }
        i += len;
    }
    pending.erase(0, i);
    return out;
}

static jstring to_jstring(JNIEnv *env, const std::u16string &s) {
    return env->NewString(reinterpret_cast<const jchar *>(s.data()), (jsize) s.size());
}

static std::string from_jstring(JNIEnv *env, jstring js) {
    if (!js) return "";
    const jchar *chars = env->GetStringChars(js, nullptr);
    jsize len = env->GetStringLength(js);
    std::string out;
    for (jsize i = 0; i < len; i++) {
        uint32_t cp = chars[i];
        if (cp >= 0xD800 && cp < 0xDC00 && i + 1 < len) {
            uint32_t lo = chars[i + 1];
            if (lo >= 0xDC00 && lo < 0xE000) {
                cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                i++;
            }
        }
        if (cp < 0x80) out.push_back((char) cp);
        else if (cp < 0x800) { out.push_back((char) (0xC0 | (cp >> 6))); out.push_back((char) (0x80 | (cp & 0x3F))); }
        else if (cp < 0x10000) {
            out.push_back((char) (0xE0 | (cp >> 12)));
            out.push_back((char) (0x80 | ((cp >> 6) & 0x3F)));
            out.push_back((char) (0x80 | (cp & 0x3F)));
        } else {
            out.push_back((char) (0xF0 | (cp >> 18)));
            out.push_back((char) (0x80 | ((cp >> 12) & 0x3F)));
            out.push_back((char) (0x80 | ((cp >> 6) & 0x3F)));
            out.push_back((char) (0x80 | (cp & 0x3F)));
        }
    }
    env->ReleaseStringChars(js, chars);
    return out;
}

static void free_all() {
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_vocab = nullptr;
}

static void throw_java(JNIEnv *env, const char *cls, const std::string &msg) {
    jclass c = env->FindClass(cls);
    if (c) env->ThrowNew(c, msg.c_str());
}

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_localagent_app_llm_LlamaBridge_nativeLoad(JNIEnv *env, jobject, jstring jpath, jint nCtx, jint nThreads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    try {
        if (!g_backend_ready) {
            llama_log_set(log_cb, nullptr);
            llama_backend_init();
            g_backend_ready = true;
        }
        free_all();
        std::string path = from_jstring(env, jpath);

        llama_model_params mp = llama_model_default_params();
        mp.n_gpu_layers = 0;
        mp.use_mmap = true;
        g_model = llama_model_load_from_file(path.c_str(), mp);
        if (!g_model) return env->NewStringUTF("Не удалось загрузить модель (файл повреждён, не хватает памяти или формат не поддерживается).");

        llama_context_params cp = llama_context_default_params();
        cp.n_ctx = (uint32_t) nCtx;
        cp.n_batch = 512;
        cp.n_threads = nThreads;
        cp.n_threads_batch = nThreads;
        g_ctx = llama_init_from_model(g_model, cp);
        if (!g_ctx) {
            free_all();
            return env->NewStringUTF("Не удалось создать контекст (мало ОЗУ). Уменьшите размер контекста или возьмите модель поменьше.");
        }
        g_vocab = llama_model_get_vocab(g_model);
        LOGI("model loaded, n_ctx=%d threads=%d", (int) nCtx, (int) nThreads);
        return env->NewStringUTF("");
    } catch (const std::exception &e) {
        free_all();
        return env->NewStringUTF(e.what());
    } catch (...) {
        free_all();
        return env->NewStringUTF("Неизвестная ошибка при загрузке");
    }
}

JNIEXPORT void JNICALL
Java_com_localagent_app_llm_LlamaBridge_nativeUnload(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_all();
}

JNIEXPORT void JNICALL
Java_com_localagent_app_llm_LlamaBridge_nativeStop(JNIEnv *, jobject) {
    g_stop.store(true);
}

JNIEXPORT jstring JNICALL
Java_com_localagent_app_llm_LlamaBridge_nativeGenerate(JNIEnv *env, jobject, jobjectArray jroles,
                                                       jobjectArray jcontents, jint maxTokens,
                                                       jfloat temperature, jstring jgrammar, jobject sink) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_ctx || !g_model) {
        throw_java(env, "java/lang/IllegalStateException", "Модель не загружена");
        return nullptr;
    }
    g_stop.store(false);

    llama_sampler *chain = nullptr;
    try {
        // ---- 1. Промпт по chat-шаблону модели ----
        jsize nMsg = env->GetArrayLength(jroles);
        std::vector<std::string> roles(nMsg), contents(nMsg);
        std::vector<llama_chat_message> msgs(nMsg);
        size_t totalLen = 0;
        for (jsize i = 0; i < nMsg; i++) {
            auto r = (jstring) env->GetObjectArrayElement(jroles, i);
            auto c = (jstring) env->GetObjectArrayElement(jcontents, i);
            roles[i] = from_jstring(env, r);
            contents[i] = from_jstring(env, c);
            env->DeleteLocalRef(r);
            env->DeleteLocalRef(c);
            msgs[i] = {roles[i].c_str(), contents[i].c_str()};
            totalLen += contents[i].size() + 32;
        }
        const char *tmpl = llama_model_chat_template(g_model, nullptr);
        std::string tmplStr = tmpl ? tmpl : "chatml";
        std::vector<char> buf(totalLen * 2 + 1024);
        int32_t n = llama_chat_apply_template(tmplStr.c_str(), msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
        if (n > (int32_t) buf.size()) {
            buf.resize(n + 16);
            n = llama_chat_apply_template(tmplStr.c_str(), msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
        }
        if (n < 0) {  // шаблон не поддерживается — падаем на ChatML
            tmplStr = "chatml";
            buf.resize(totalLen * 2 + 1024);
            n = llama_chat_apply_template(tmplStr.c_str(), msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
        }
        if (n < 0) {
            throw_java(env, "java/lang/IllegalStateException", "Не удалось применить chat-шаблон");
            return nullptr;
        }
        std::string prompt(buf.data(), (size_t) n);

        // ---- 2. Токенизация ----
        int32_t nTok = -llama_tokenize(g_vocab, prompt.c_str(), (int32_t) prompt.size(), nullptr, 0, true, true);
        if (nTok <= 0) {
            throw_java(env, "java/lang/IllegalStateException", "Токенизация не удалась");
            return nullptr;
        }
        std::vector<llama_token> tokens(nTok);
        if (llama_tokenize(g_vocab, prompt.c_str(), (int32_t) prompt.size(), tokens.data(), nTok, true, true) < 0) {
            throw_java(env, "java/lang/IllegalStateException", "Токенизация не удалась");
            return nullptr;
        }
        // Защита от двойного BOS (когда шаблон уже вставил его сам).
        llama_token bos = llama_vocab_bos(g_vocab);
        if (tokens.size() > 1 && bos != LLAMA_TOKEN_NULL && tokens[0] == bos && tokens[1] == bos) {
            tokens.erase(tokens.begin());
        }
        int32_t nCtx = (int32_t) llama_n_ctx(g_ctx);
        if ((int32_t) tokens.size() + 16 >= nCtx) {
            throw_java(env, "java/lang/IllegalArgumentException", "prompt_too_long");
            return nullptr;
        }
        int32_t budget = std::min<int32_t>(maxTokens, nCtx - (int32_t) tokens.size() - 4);

        // ---- 3. Сэмплер (грамматика → top_k → top_p → temp → dist) ----
        llama_sampler_chain_params sp = llama_sampler_chain_default_params();
        chain = llama_sampler_chain_init(sp);
        std::string grammar = from_jstring(env, jgrammar);
        if (!grammar.empty()) {
            llama_sampler *g = llama_sampler_init_grammar(g_vocab, grammar.c_str(), "root");
            if (!g) {
                llama_sampler_free(chain);
                chain = nullptr;
                throw_java(env, "java/lang/IllegalStateException", "Ошибка в GBNF-грамматике");
                return nullptr;
            }
            llama_sampler_chain_add(chain, g);
        }
        if (temperature <= 0.01f) {
            llama_sampler_chain_add(chain, llama_sampler_init_greedy());
        } else {
            llama_sampler_chain_add(chain, llama_sampler_init_top_k(40));
            llama_sampler_chain_add(chain, llama_sampler_init_top_p(0.95f, 1));
            llama_sampler_chain_add(chain, llama_sampler_init_temp(temperature));
            llama_sampler_chain_add(chain, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
        }

        // ---- 4. Префилл ----
        llama_memory_clear(llama_get_memory(g_ctx), true);
        const int32_t nBatch = (int32_t) llama_n_batch(g_ctx);
        for (int32_t i = 0; i < (int32_t) tokens.size(); i += nBatch) {
            if (g_stop.load()) { llama_sampler_free(chain); return env->NewStringUTF(""); }
            int32_t cnt = std::min<int32_t>(nBatch, (int32_t) tokens.size() - i);
            llama_batch b = llama_batch_get_one(tokens.data() + i, cnt);
            if (llama_decode(g_ctx, b) != 0) {
                llama_sampler_free(chain);
                chain = nullptr;
                throw_java(env, "java/lang/IllegalStateException", "llama_decode не удался на префилле");
                return nullptr;
            }
        }

        // ---- 5. Генерация ----
        jclass sinkCls = env->GetObjectClass(sink);
        jmethodID onToken = env->GetMethodID(sinkCls, "onToken", "(Ljava/lang/String;)Z");
        std::u16string full;
        std::string pending;
        char piece[256];
        for (int32_t i = 0; i < budget; i++) {
            if (g_stop.load()) break;
            llama_token tok = llama_sampler_sample(chain, g_ctx, -1);
            if (llama_vocab_is_eog(g_vocab, tok)) break;
            int32_t pl = llama_token_to_piece(g_vocab, tok, piece, sizeof(piece), 0, false);
            if (pl > 0) {
                pending.append(piece, (size_t) pl);
                std::u16string chunk = drain_utf8(pending);
                if (!chunk.empty()) {
                    full += chunk;
                    jstring js = to_jstring(env, chunk);
                    jboolean cont = env->CallBooleanMethod(sink, onToken, js);
                    env->DeleteLocalRef(js);
                    if (env->ExceptionCheck() || !cont) break;
                }
            }
            llama_batch nb = llama_batch_get_one(&tok, 1);
            if (llama_decode(g_ctx, nb) != 0) break;
        }
        llama_sampler_free(chain);
        chain = nullptr;
        return to_jstring(env, full);
    } catch (const std::exception &e) {
        if (chain) llama_sampler_free(chain);
        throw_java(env, "java/lang/RuntimeException", e.what());
        return nullptr;
    } catch (...) {
        if (chain) llama_sampler_free(chain);
        throw_java(env, "java/lang/RuntimeException", "Неизвестная ошибка генерации");
        return nullptr;
    }
}

}  // extern "C"

package com.localagent.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class CatalogEntry(
    val title: String,
    val repo: String,
    val params: String,
    val note: String,
    val good4agent: Boolean,
)

data class RepoInfo(val id: String, val downloads: Long, val likes: Int)

data class GgufFile(val path: String, val sizeBytes: Long) {
    val name: String get() = path.substringAfterLast('/')
}

/** Подборка «без цензуры» (abliterated / uncensored). Репозитории проверены поиском по Hugging Face. */
val CURATED = listOf(
    CatalogEntry(
        "Qwen3 4B abliterated v2", "mradermacher/Huihui-Qwen3-4B-abliterated-v2-GGUF", "4B",
        "Лучший баланс ума и скорости, хороший русский. Рекомендуется для агента.", true,
    ),
    CatalogEntry(
        "Gemma 3 4B abliterated", "mlabonne/gemma-3-4b-it-abliterated-GGUF", "4B",
        "Очень хороший русский. Автор предупреждает: изредка бывают «битые» символы.", false,
    ),
    CatalogEntry(
        "Gemma 3 1B abliterated", "bartowski/huihui-ai_gemma-3-1b-it-abliterated-GGUF", "1B",
        "Самая быстрая. Для простых вопросов и коротких текстов.", false,
    ),
    CatalogEntry(
        "Llama 3.2 3B abliterated", "mav23/Llama-3.2-3B-Instruct-abliterated-GGUF", "3B",
        "Быстрая, неплохо следует инструкциям. Русский слабее Qwen/Gemma.", true,
    ),
    CatalogEntry(
        "Dolphin 3.0 Llama 3.2 3B", "bartowski/Dolphin3.0-Llama3.2-3B-GGUF", "3B",
        "Не навязывает мораль, поведение задаётся системным промптом.", true,
    ),
)

val SEARCH_PRESETS = listOf("abliterated", "uncensored", "dolphin", "heretic", "qwen3 abliterated", "gemma abliterated")

private val QUANT_PREFERENCE = listOf("Q4_K_M", "Q4_K_S", "Q4_0", "IQ4_XS", "Q5_K_M", "Q5_K_S", "Q6_K", "Q8_0")

/** Выбирает квант, который лучше всего подходит телефону (Q4_K_M и ближайшие). */
fun recommended(files: List<GgufFile>): GgufFile? {
    for (q in QUANT_PREFERENCE) {
        files.firstOrNull { it.name.contains(q, ignoreCase = true) }?.let { return it }
    }
    return files.minByOrNull { it.sizeBytes }
}

enum class Fit(val label: String) { OK("подойдёт"), TIGHT("впритык"), TOO_BIG("не влезет в ОЗУ") }

fun fitFor(sizeBytes: Long, totalRam: Long): Fit = when {
    sizeBytes <= 0 -> Fit.OK
    sizeBytes < totalRam * 0.36 -> Fit.OK
    sizeBytes < totalRam * 0.50 -> Fit.TIGHT
    else -> Fit.TOO_BIG
}

object HfApi {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "LocalAgent/1.0")
        try {
            val code = c.responseCode
            if (code == 401 || code == 403) throw IOException("Репозиторий закрыт (нужен вход на Hugging Face)")
            if (code != 200) throw IOException("Hugging Face вернул HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    suspend fun search(query: String): List<RepoInfo> = withContext(Dispatchers.IO) {
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        val json = JSONArray(get("https://huggingface.co/api/models?search=$q&filter=gguf&sort=downloads&direction=-1&limit=40"))
        (0 until json.length()).map {
            val o = json.getJSONObject(it)
            RepoInfo(o.getString("id"), o.optLong("downloads"), o.optInt("likes"))
        }
    }

    suspend fun files(repo: String): List<GgufFile> = withContext(Dispatchers.IO) {
        val json = JSONArray(get("https://huggingface.co/api/models/$repo/tree/main?recursive=true"))
        (0 until json.length()).mapNotNull {
            val o = json.getJSONObject(it)
            val path = o.optString("path")
            if (o.optString("type") != "file" || !path.endsWith(".gguf", true)) return@mapNotNull null
            if (path.contains("mmproj", true) || path.contains("-of-0")) return@mapNotNull null // vision-часть и split-файлы не поддерживаем
            val size = o.optJSONObject("lfs")?.optLong("size", 0L)?.takeIf { s -> s > 0 } ?: o.optLong("size", 0L)
            GgufFile(path, size)
        }.sortedBy { it.sizeBytes }
    }

    fun downloadUrl(repo: String, path: String): String {
        val enc = path.split('/').joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
        return "https://huggingface.co/$repo/resolve/main/$enc?download=true"
    }
}

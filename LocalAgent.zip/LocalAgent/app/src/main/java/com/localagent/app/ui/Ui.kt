package com.localagent.app.ui

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localagent.app.AppViewModel
import com.localagent.app.agent.AgentService
import com.localagent.app.data.CURATED
import com.localagent.app.data.Fit
import com.localagent.app.data.GgufFile
import com.localagent.app.data.SEARCH_PRESETS
import com.localagent.app.data.fitFor
import com.localagent.app.data.recommended
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

private class TabDef(val title: String, val icon: ImageVector)

private val TABS = listOf(
    TabDef("Каталог", Icons.Default.Search),
    TabDef("Модели", Icons.Default.Menu),
    TabDef("Чат", Icons.Default.Face),
    TabDef("Агент", Icons.Default.PlayArrow),
)

@Composable
fun App(vm: AppViewModel, onImport: () -> Unit, onOpenA11y: () -> Unit, onOpenAppInfo: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                TABS.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.title) },
                        label = { Text(t.title) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> CatalogScreen(vm)
                1 -> ModelsScreen(vm, onImport)
                2 -> ChatScreen(vm, goModels = { tab = 1 })
                else -> AgentScreen(vm, onOpenA11y, onOpenAppInfo, goModels = { tab = 1 })
            }
        }
    }
}

fun fmtSize(b: Long): String = when {
    b <= 0 -> "размер ?"
    b >= 1L shl 30 -> String.format(Locale.US, "%.2f ГБ", b / (1024.0 * 1024 * 1024))
    else -> "${b / (1024 * 1024)} МБ"
}

@Composable
private fun Title(text: String) =
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 6.dp))

// ====================================================================== КАТАЛОГ

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CatalogScreen(vm: AppViewModel) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(14.dp)) {
                    val gb = vm.totalRam / (1024.0 * 1024 * 1024)
                    Text("ОЗУ телефона: ${String.format(Locale.US, "%.1f", gb)} ГБ", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Комфортно запускаются модели в формате Q4 размером до ~${String.format(Locale.US, "%.1f", gb * 0.36)} ГБ. " +
                            "Модели «abliterated» и «uncensored» — версии с убранными отказами; ответственность за использование на вас.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
        item { Title("Подборка (без цензуры)") }
        items(CURATED, key = { "c:" + it.repo }) { e ->
            RepoBlock(
                vm, e.repo, e.title,
                "${e.params} · ${e.note}" + if (e.good4agent) " · подходит для агента" else "",
            )
        }
        item { Title("Поиск по Hugging Face") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = vm.query,
                    onValueChange = { vm.query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Например: abliterated, uncensored, dolphin") },
                    trailingIcon = {
                        IconButton(onClick = { vm.search() }) { Icon(Icons.Default.Search, "Искать") }
                    },
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SEARCH_PRESETS.forEach { p ->
                        SuggestionChip(onClick = { vm.query = p; vm.search() }, label = { Text(p) })
                    }
                }
                if (vm.searching) CircularProgressIndicator(Modifier.padding(8.dp))
                vm.searchError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        }
        items(vm.results, key = { "r:" + it.id }) { r ->
            RepoBlock(
                vm, r.id, r.id.substringAfter('/'),
                "от ${r.id.substringBefore('/')} · ⬇ ${r.downloads} · ♥ ${r.likes}",
            )
        }
    }
}

@Composable
private fun RepoBlock(vm: AppViewModel, repo: String, title: String, subtitle: String) {
    val open = vm.openRepo == repo
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth().clickable { vm.toggleRepo(repo) }, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleSmall)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(repo, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                }
                Text(if (open) "▲" else "▼")
            }
            if (open) {
                Spacer(Modifier.height(8.dp))
                when {
                    vm.filesLoading -> CircularProgressIndicator(Modifier.padding(8.dp))
                    vm.filesError != null -> Text(vm.filesError!!, color = MaterialTheme.colorScheme.error)
                    else -> {
                        val rec = recommended(vm.repoFiles)
                        vm.repoFiles.forEach { FileRow(vm, repo, it, it == rec) }
                    }
                }
            }
        }
    }
}

@Composable
private fun FileRow(vm: AppViewModel, repo: String, f: GgufFile, isRec: Boolean) {
    val dl = vm.downloads[f.name]
    val installed = vm.installed.any { it.name == f.name }
    val fit = fitFor(f.sizeBytes, vm.totalRam)
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(f.name, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    "${fmtSize(f.sizeBytes)} · ${fit.label}" + if (isRec) " · ★ рекомендуем" else "",
                    style = MaterialTheme.typography.labelSmall,
                    color = when (fit) {
                        Fit.OK -> MaterialTheme.colorScheme.primary
                        Fit.TIGHT -> MaterialTheme.colorScheme.tertiary
                        Fit.TOO_BIG -> MaterialTheme.colorScheme.error
                    },
                )
            }
            when {
                installed -> Text("Установлено ✓", style = MaterialTheme.typography.labelMedium)
                dl?.active == true -> TextButton(onClick = { vm.cancelDownload(f.name) }) { Text("Пауза") }
                else -> FilledTonalButton(onClick = { vm.download(repo, f) }) {
                    Text(if (dl?.error != null) "Продолжить" else "Скачать")
                }
            }
        }
        if (dl != null) {
            if (dl.active) {
                LinearProgressIndicator(
                    progress = { if (dl.total > 0) (dl.done.toFloat() / dl.total).coerceIn(0f, 1f) else 0f },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                )
            }
            Text(
                "${dl.done / (1024 * 1024)} / ${if (dl.total > 0) dl.total / (1024 * 1024) else "?"} МБ",
                style = MaterialTheme.typography.labelSmall,
            )
            dl.error?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error) }
        }
        HorizontalDivider(Modifier.padding(top = 6.dp))
    }
}

// ====================================================================== МОДЕЛИ

@Composable
fun ModelsScreen(vm: AppViewModel, onImport: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(14.dp)) {
                Text("Загружена сейчас", style = MaterialTheme.typography.labelMedium)
                Text(
                    when {
                        vm.loading -> "Загрузка модели…"
                        vm.loadedName != null -> vm.loadedName!!
                        else -> "— ничего"
                    },
                    style = MaterialTheme.typography.titleSmall,
                )
                if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                vm.loadError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        }

        Title("Скачанные модели")
        if (vm.installed.isEmpty()) {
            Text("Пока пусто. Скачайте модель во вкладке «Каталог» или импортируйте .gguf с телефона.", style = MaterialTheme.typography.bodySmall)
        }
        vm.installed.forEach { f ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(f.name, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(fmtSize(f.length()), style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                        Button(onClick = { vm.loadModel(f) }, enabled = !vm.loading && vm.loadedName != f.name) {
                            Text(if (vm.loadedName == f.name) "Загружена" else "Загрузить")
                        }
                        OutlinedButton(onClick = { vm.deleteModel(f) }, enabled = vm.loadedName != f.name) { Text("Удалить") }
                    }
                }
            }
        }
        OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("Импортировать .gguf с телефона") }
        vm.importing?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        Title("Настройки")

        Text("Контекст (токенов): ${vm.nCtx}", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(2048, 4096, 8192).forEach { c ->
                FilterChip(selected = vm.nCtx == c, onClick = { vm.nCtx = c; vm.saveSettings() }, label = { Text("$c") })
            }
        }
        Text("Потоки CPU: ${vm.threads}", style = MaterialTheme.typography.labelLarge)
        Slider(
            value = vm.threads.toFloat(), onValueChange = { vm.threads = it.toInt() },
            onValueChangeFinished = { vm.saveSettings() }, valueRange = 2f..8f, steps = 5,
        )
        Text("Температура: ${String.format(Locale.US, "%.2f", vm.temperature)}", style = MaterialTheme.typography.labelLarge)
        Slider(
            value = vm.temperature, onValueChange = { vm.temperature = it },
            onValueChangeFinished = { vm.saveSettings() }, valueRange = 0f..1.5f,
        )
        OutlinedTextField(
            value = vm.systemPrompt, onValueChange = { vm.systemPrompt = it; vm.saveSettings() },
            label = { Text("Системный промпт чата") }, modifier = Modifier.fillMaxWidth(), minLines = 3,
        )
        Text(
            "Контекст и потоки применяются при следующей загрузке модели. Для 8 ГБ ОЗУ оставьте 4096 и 4 потока.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ====================================================================== ЧАТ

private val THINK = Regex("<think>[\\s\\S]*?(</think>|\\z)")
private fun visible(t: String) = t.replace(THINK, "").trim()

@Composable
fun ChatScreen(vm: AppViewModel, goModels: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val lastLen = vm.chat.lastOrNull()?.text?.length ?: 0
    LaunchedEffect(vm.chat.size, lastLen / 40) {
        if (vm.chat.isNotEmpty()) listState.scrollToItem(vm.chat.lastIndex)
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(vm.loadedName ?: "Модель не загружена", Modifier.weight(1f), style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            TextButton(onClick = { vm.clearChat() }) { Text("Очистить") }
        }
        if (vm.loadedName == null) {
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Сначала загрузите модель", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Button(onClick = goModels) { Text("К моделям") }
            }
        } else {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), state = listState,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(vm.chat) { m ->
                    val mine = m.role == "user"
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.widthIn(max = 320.dp),
                        ) {
                            SelectionContainer {
                                Text(
                                    visible(m.text).ifEmpty { if (!mine && vm.generating) "…" else "" },
                                    Modifier.padding(12.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Сообщение") }, maxLines = 5,
                enabled = vm.loadedName != null,
            )
            if (vm.generating) {
                TextButton(onClick = { vm.stopGeneration() }) { Text("■") }
            } else {
                IconButton(
                    onClick = { vm.send(input); input = "" },
                    enabled = vm.loadedName != null && input.isNotBlank(),
                ) { Icon(Icons.AutoMirrored.Filled.Send, "Отправить") }
            }
        }
    }
}

// ====================================================================== АГЕНТ

@Composable
fun AgentScreen(vm: AppViewModel, onOpenA11y: () -> Unit, onOpenAppInfo: () -> Unit, goModels: () -> Unit) {
    var enabled by remember { mutableStateOf(AgentService.instance != null) }
    var task by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            enabled = AgentService.instance != null
            delay(1000)
        }
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (enabled) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
                ),
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        if (enabled) "Служба доступности включена ✓" else "Служба доступности выключена",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    if (!enabled) {
                        Text(
                            "1) Нажмите «Разрешить ограниченные настройки» → в меню ⋮ выберите «Разрешить ограниченные настройки» (Android блокирует это для APK не из магазина).\n" +
                                "2) Затем «Открыть настройки доступности» → Local Agent → включить.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onOpenAppInfo) { Text("Разрешить огранич.") }
                            Button(onClick = onOpenA11y) { Text("Доступность") }
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Подтверждать каждое действие", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Если выключить — подтверждение всё равно требуется для ввода текста и для кнопок вроде «Оплатить», «Удалить», «Отправить».",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = vm.confirmEvery, onCheckedChange = { vm.confirmEvery = it; vm.saveSettings() })
            }
        }
        item {
            if (vm.loadedName == null) {
                OutlinedButton(onClick = goModels, modifier = Modifier.fillMaxWidth()) { Text("Загрузите модель →") }
            } else {
                Text("Модель: ${vm.loadedName}", style = MaterialTheme.typography.labelMedium)
            }
        }
        item {
            OutlinedTextField(
                value = task, onValueChange = { task = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Задача, например: «Открой Настройки и включи Wi-Fi»") }, minLines = 2,
                enabled = !vm.agentRunning,
            )
        }
        item {
            if (vm.agentRunning) {
                Button(onClick = { vm.stopAgent() }, modifier = Modifier.fillMaxWidth()) { Text("■ Остановить") }
            } else {
                Button(
                    onClick = { vm.startAgent(task) },
                    enabled = enabled && vm.loadedName != null && task.isNotBlank() && !vm.generating,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Запустить агента") }
            }
        }
        item {
            Text(
                "Агент читает текст на экране и по одному шагу нажимает, вводит текст и листает. Модель работает на телефоне, " +
                    "данные никуда не отправляются. Один шаг занимает 10–60 секунд — это нормально для локальной модели. " +
                    "Не используйте агента для платежей и банковских приложений. Красная кнопка «СТОП» всегда поверх экрана.",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        itemsIndexed(vm.agentLog) { _, line ->
            Text(line, style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp))
        }
    }
}

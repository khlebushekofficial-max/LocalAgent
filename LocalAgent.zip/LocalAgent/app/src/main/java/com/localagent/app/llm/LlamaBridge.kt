package com.localagent.app.llm

import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

fun interface TokenSink {
    /** Возвращает false, чтобы остановить генерацию. */
    fun onToken(piece: String): Boolean
}

object LlamaBridge {
    init {
        System.loadLibrary("localagent_llm")
    }

    /** Возвращает пустую строку при успехе, иначе текст ошибки. */
    external fun nativeLoad(path: String, nCtx: Int, nThreads: Int): String
    external fun nativeGenerate(
        roles: Array<String>,
        contents: Array<String>,
        maxTokens: Int,
        temperature: Float,
        grammar: String?,
        sink: TokenSink,
    ): String

    external fun nativeStop()
    external fun nativeUnload()
}

data class ChatMsg(val role: String, val content: String)

/** Все вызовы модели идут через один поток — чат и агент не мешают друг другу. */
object LlmEngine {
    private val dispatcher = Executors.newSingleThreadExecutor { r ->
        Thread(null, r, "llm", 16L * 1024 * 1024)
    }.asCoroutineDispatcher()

    @Volatile
    var loadedName: String? = null
        private set

    suspend fun load(file: File, nCtx: Int, threads: Int): String? = withContext(dispatcher) {
        LlamaBridge.nativeUnload()
        loadedName = null
        val err = LlamaBridge.nativeLoad(file.absolutePath, nCtx, threads)
        if (err.isEmpty()) {
            loadedName = file.name
            null
        } else err
    }

    /**
     * @throws IllegalArgumentException("prompt_too_long") если промпт не влезает в контекст
     */
    suspend fun generate(
        messages: List<ChatMsg>,
        maxTokens: Int,
        temperature: Float,
        grammar: String? = null,
        onToken: (String) -> Unit = {},
    ): String {
        val job = currentCoroutineContext()[Job]
        return withContext(dispatcher) {
            LlamaBridge.nativeGenerate(
                messages.map { it.role }.toTypedArray(),
                messages.map { it.content }.toTypedArray(),
                maxTokens,
                temperature,
                grammar,
                TokenSink { piece ->
                    onToken(piece)
                    job?.isActive != false
                },
            )
        }
    }

    fun stop() = LlamaBridge.nativeStop()
}

package com.localagent.app

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.localagent.app.agent.AgentRunner
import com.localagent.app.data.GgufFile
import com.localagent.app.data.HfApi
import com.localagent.app.data.Downloader
import com.localagent.app.data.ModelStore
import com.localagent.app.data.RepoInfo
import com.localagent.app.llm.ChatMsg
import com.localagent.app.llm.LlmEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

const val DEFAULT_SYSTEM_PROMPT =
    "Ты — полезный ассистент. Отвечай прямо, подробно и по делу, на языке пользователя."

class Dl(val name: String, total: Long) {
    var done by mutableLongStateOf(0L)
    var total by mutableLongStateOf(total)
    var error by mutableStateOf<String?>(null)
    var active by mutableStateOf(true)
}

class UiMsg(val role: String, text: String) {
    var text by mutableStateOf(text)
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    val store = ModelStore(app)

    val totalRam: Long = ActivityManager.MemoryInfo().also {
        (app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(it)
    }.totalMem

    // ---------------- настройки ----------------
    var systemPrompt by mutableStateOf(prefs.getString("sys", DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT)
    var temperature by mutableFloatStateOf(prefs.getFloat("temp", 0.7f))
    var nCtx by mutableIntStateOf(prefs.getInt("ctx", 4096))
    var threads by mutableIntStateOf(prefs.getInt("threads", 4))
    var confirmEvery by mutableStateOf(prefs.getBoolean("confirm_all", true))

    fun saveSettings() {
        prefs.edit()
            .putString("sys", systemPrompt)
            .putFloat("temp", temperature)
            .putInt("ctx", nCtx)
            .putInt("threads", threads)
            .putBoolean("confirm_all", confirmEvery)
            .apply()
    }

    // ---------------- модели на устройстве ----------------
    val installed = mutableStateListOf<File>()
    var loadedName by mutableStateOf<String?>(null)
    var loading by mutableStateOf(false)
    var loadError by mutableStateOf<String?>(null)
    var importing by mutableStateOf<String?>(null)

    init {
        refreshInstalled()
        loadedName = LlmEngine.loadedName
    }

    fun refreshInstalled() {
        installed.clear()
        installed.addAll(store.list())
    }

    fun loadModel(f: File) {
        if (loading || generating || agentRunning) return
        loading = true
        loadError = null
        viewModelScope.launch {
            val err = LlmEngine.load(f, nCtx, threads)
            loadedName = if (err == null) f.name else null
            loadError = err
            loading = false
            if (err == null) chat.clear()
        }
    }

    fun deleteModel(f: File) {
        if (loadedName == f.name) return
        f.delete()
        refreshInstalled()
    }

    fun importModel(uri: Uri) {
        importing = "копирую…"
        viewModelScope.launch {
            try {
                store.import(uri) { importing = "скопировано ${it / (1024 * 1024)} МБ" }
                refreshInstalled()
                importing = null
            } catch (e: Exception) {
                importing = "Ошибка: ${e.message}"
            }
        }
    }

    // ---------------- каталог ----------------
    var query by mutableStateOf("abliterated")
    val results = mutableStateListOf<RepoInfo>()
    var searching by mutableStateOf(false)
    var searchError by mutableStateOf<String?>(null)

    var openRepo by mutableStateOf<String?>(null)
    val repoFiles = mutableStateListOf<GgufFile>()
    var filesLoading by mutableStateOf(false)
    var filesError by mutableStateOf<String?>(null)

    fun search() {
        if (searching) return
        searching = true
        searchError = null
        viewModelScope.launch {
            try {
                val r = HfApi.search(query)
                results.clear(); results.addAll(r)
                if (r.isEmpty()) searchError = "Ничего не найдено"
            } catch (e: Exception) {
                searchError = e.message ?: "Нет сети"
            }
            searching = false
        }
    }

    fun toggleRepo(repo: String) {
        if (openRepo == repo) { openRepo = null; return }
        openRepo = repo
        repoFiles.clear()
        filesError = null
        filesLoading = true
        viewModelScope.launch {
            try {
                val f = HfApi.files(repo)
                if (openRepo == repo) {
                    repoFiles.addAll(f)
                    if (f.isEmpty()) filesError = "В репозитории нет подходящих .gguf файлов"
                }
            } catch (e: Exception) {
                filesError = e.message ?: "Нет сети"
            }
            filesLoading = false
        }
    }

    // ---------------- загрузки ----------------
    val downloads = mutableStateMapOf<String, Dl>()
    private val dlJobs = HashMap<String, Job>()
    val downloading: Boolean get() = downloads.values.any { it.active } || importing == "копирую…"

    fun download(repo: String, f: GgufFile) {
        val name = f.name
        if (downloads[name]?.active == true) return
        val dl = Dl(name, f.sizeBytes)
        downloads[name] = dl
        dlJobs[name] = viewModelScope.launch {
            try {
                Downloader.download(HfApi.downloadUrl(repo, f.path), File(store.dir, name)) { d, t ->
                    dl.done = d
                    if (t > 0) dl.total = t
                }
                downloads.remove(name)
                refreshInstalled()
            } catch (e: CancellationException) {
                dl.active = false
                dl.error = "Пауза (нажмите, чтобы продолжить)"
                throw e
            } catch (e: Exception) {
                dl.active = false
                dl.error = e.message ?: e.toString()
            }
        }
    }

    fun cancelDownload(name: String) {
        dlJobs[name]?.cancel()
    }

    // ---------------- чат ----------------
    val chat = mutableStateListOf<UiMsg>()
    var generating by mutableStateOf(false)
    private var genJob: Job? = null

    private fun noThink(): Boolean {
        val n = loadedName ?: return false
        return n.contains("qwen3", true) && !n.contains("2507", true)
    }

    fun send(text: String) {
        if (generating || text.isBlank() || LlmEngine.loadedName == null) return
        chat.add(UiMsg("user", text.trim()))
        val reply = UiMsg("assistant", "")
        chat.add(reply)
        generating = true
        genJob = viewModelScope.launch {
            val sb = StringBuilder()
            try {
                var keep = chat.size - 1 // без пустого ответа
                var attempt = 0
                while (true) {
                    val msgs = buildHistory(keep)
                    try {
                        sb.clear()
                        var last = 0L
                        val full = LlmEngine.generate(msgs, maxTokens = 1024, temperature = temperature) { piece ->
                            sb.append(piece)
                            val now = System.currentTimeMillis()
                            if (now - last > 60) { reply.text = sb.toString(); last = now }
                        }
                        reply.text = full
                        break
                    } catch (e: IllegalArgumentException) {
                        // не влезло в контекст — выкидываем самые старые сообщения
                        keep -= 2
                        if (keep < 1 || ++attempt > 20) {
                            reply.text = "⚠ Сообщение слишком длинное для выбранного контекста."
                            break
                        }
                    }
                }
            } catch (e: CancellationException) {
                reply.text = sb.toString() // оставляем то, что успело сгенерироваться
                throw e
            } catch (e: Exception) {
                reply.text = "⚠ ${e.message}"
            } finally {
                generating = false
            }
        }
    }

    /** Берёт последние `keep` сообщений чата. Для Qwen3 отключает режим рассуждений. */
    private fun buildHistory(keep: Int): List<ChatMsg> {
        val tail = chat.take(chat.size - 1).takeLast(keep.coerceAtLeast(1))
        val out = ArrayList<ChatMsg>()
        if (systemPrompt.isNotBlank()) out.add(ChatMsg("system", systemPrompt))
        tail.forEachIndexed { i, m ->
            val isLastUser = i == tail.lastIndex && m.role == "user"
            out.add(ChatMsg(m.role, if (isLastUser && noThink()) m.text + " /no_think" else m.text))
        }
        return out
    }

    fun stopGeneration() {
        LlmEngine.stop()
        genJob?.cancel()
    }

    fun clearChat() {
        if (!generating) chat.clear()
    }

    // ---------------- агент ----------------
    val agentLog = mutableStateListOf<String>()
    var agentRunning by mutableStateOf(false)
    private var agentJob: Job? = null

    fun startAgent(task: String) {
        if (agentRunning || generating || task.isBlank()) return
        agentRunning = true
        agentLog.clear()
        val runner = AgentRunner(
            log = { line -> agentLog.add(line) },
            confirmEvery = confirmEvery,
            modelName = loadedName ?: "",
        )
        agentJob = viewModelScope.launch {
            try {
                runner.run(task.trim()) { stopAgent() }
            } catch (e: CancellationException) {
                agentLog.add("⏹ Остановлено")
                throw e
            } catch (e: Exception) {
                agentLog.add("⚠ Ошибка: ${e.message}")
            } finally {
                agentRunning = false
            }
        }
    }

    fun stopAgent() {
        LlmEngine.stop()
        agentJob?.cancel()
    }
}

package com.localagent.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

class ModelStore(private val ctx: Context) {
    val dir: File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "models").apply { mkdirs() }

    fun list(): List<File> =
        dir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", true) }?.sortedBy { it.name }.orEmpty()

    /** Копирует выбранный пользователем .gguf в папку моделей. */
    suspend fun import(uri: Uri, onProgress: (Long) -> Unit): File = withContext(Dispatchers.IO) {
        var name = "imported-${System.currentTimeMillis()}.gguf"
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i)
        }
        if (!name.endsWith(".gguf", true)) throw IOException("Нужен файл .gguf")
        val out = File(dir, name)
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(out).use { o ->
                val buf = ByteArray(256 * 1024)
                var total = 0L
                while (true) {
                    coroutineContext.ensureActive()
                    val n = input.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                    total += n
                    onProgress(total)
                }
            }
        } ?: throw IOException("Не удалось открыть файл")
        out
    }
}

object Downloader {
    /** Скачивание с докачкой (.part + Range). */
    suspend fun download(url: String, dest: File, onProgress: (done: Long, total: Long) -> Unit) =
        withContext(Dispatchers.IO) {
            val part = File(dest.path + ".part")
            var existing = if (part.exists()) part.length() else 0L
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = true
            c.connectTimeout = 20000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "LocalAgent/1.0")
            if (existing > 0) c.setRequestProperty("Range", "bytes=$existing-")
            try {
                val code = c.responseCode
                when (code) {
                    200 -> existing = 0L // сервер игнорирует Range — качаем заново
                    206 -> {}
                    416 -> { // файл уже докачан
                        part.renameTo(dest)
                        return@withContext
                    }
                    401, 403 -> throw IOException("Доступ закрыт (HTTP $code). Репозиторий требует вход на Hugging Face.")
                    else -> throw IOException("Ошибка загрузки: HTTP $code")
                }
                val len = c.contentLengthLong
                val total = if (len > 0) existing + len else -1L
                FileOutputStream(part, existing > 0).use { out ->
                    c.inputStream.use { input ->
                        val buf = ByteArray(256 * 1024)
                        var done = existing
                        while (true) {
                            coroutineContext.ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            onProgress(done, total)
                        }
                    }
                }
                if (dest.exists()) dest.delete()
                if (!part.renameTo(dest)) throw IOException("Не удалось сохранить файл")
            } finally {
                c.disconnect()
            }
        }
}

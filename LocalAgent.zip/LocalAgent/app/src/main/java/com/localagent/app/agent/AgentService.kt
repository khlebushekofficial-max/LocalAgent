package com.localagent.app.agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

enum class Approval { ALLOW, DENY, STOP }

/**
 * Служба доступности: читает экран и выполняет действия.
 * Включается пользователем вручную в Настройках — это и есть главное разрешение.
 * Каждое действие модели (по умолчанию) подтверждается плашкой поверх экрана.
 */
class AgentService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AgentService? = null
            private set
    }

    private val nodes = ArrayList<AccessibilityNodeInfo>()
    private val labels = ArrayList<String>()
    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private var stopView: View? = null

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    // ------------------------------------------------------------------ чтение экрана

    /** Текстовое описание экрана: пронумерованные элементы, которые модель может использовать как id. */
    fun dumpScreen(maxChars: Int = 2200): String {
        val root = rootInActiveWindow ?: return "(экран недоступен)"
        nodes.clear()
        labels.clear()
        val sb = StringBuilder("app: ${root.packageName}\n")
        var canScroll = false

        fun walk(n: AccessibilityNodeInfo, clickableAbove: Boolean) {
            if (sb.length > maxChars || nodes.size >= 80) return
            if (!n.isVisibleToUser) return
            val raw = (n.text ?: n.contentDescription)?.toString()?.replace('\n', ' ')?.trim().orEmpty()
            val text = if (n.isPassword) "••••" else raw.take(60)
            val clickable = n.isClickable || clickableAbove
            if (n.isScrollable) canScroll = true
            if (text.isNotEmpty() || n.isEditable) {
                val kind = n.className?.toString()?.substringAfterLast('.') ?: "View"
                val flags = buildList {
                    if (clickable) add("click")
                    if (n.isEditable) add("edit")
                    if (n.isCheckable) add(if (n.isChecked) "on" else "off")
                    if (n.isPassword) add("password")
                }.joinToString(",")
                val id = nodes.size
                nodes.add(n)
                labels.add(text.ifEmpty { kind })
                sb.append("[$id] $kind \"$text\"")
                if (flags.isNotEmpty()) sb.append(" ($flags)")
                sb.append('\n')
            }
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { walk(it, clickable) }
            }
        }
        walk(root, false)
        if (canScroll) sb.append("(экран можно прокручивать)\n")
        return sb.toString().take(maxChars + 200)
    }

    fun labelOf(id: Int): String = labels.getOrNull(id) ?: "?"
    fun isPasswordField(id: Int): Boolean = nodes.getOrNull(id)?.isPassword == true

    // ------------------------------------------------------------------ действия

    fun tap(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "нет элемента [$id]"
        n.refresh()
        var c: AccessibilityNodeInfo? = n
        var depth = 0
        while (c != null && depth < 7) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok"
            c = c.parent
            depth++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        return if (gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat(), 60)) "ok (жест)" else "не удалось нажать"
    }

    fun typeText(id: Int, text: String): String {
        val n = nodes.getOrNull(id) ?: return "нет элемента [$id]"
        if (n.isPassword) return "отказ: поле пароля"
        if (!n.isEditable) return "элемент [$id] не для ввода текста"
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "ok" else "не удалось ввести текст"
    }

    fun scroll(down: Boolean): String {
        val root = rootInActiveWindow
        val target = root?.let { findScrollable(it) }
        val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (target != null && target.performAction(action)) return "ok"
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val (y1, y2) = if (down) m.heightPixels * 0.7f to m.heightPixels * 0.3f else m.heightPixels * 0.3f to m.heightPixels * 0.7f
        return if (gesture(x, y1, x, y2, 300)) "ok (жест)" else "не удалось прокрутить"
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { c -> findScrollable(c)?.let { return it } }
        }
        return null
    }

    fun back(): String = if (performGlobalAction(GLOBAL_ACTION_BACK)) "ok" else "не удалось"
    fun goHome(): String = if (performGlobalAction(GLOBAL_ACTION_HOME)) "ok" else "не удалось"

    fun openApp(name: String): String {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            ?: return "приложение «$name» не найдено"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "нельзя запустить"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return "ok (${match.loadLabel(pm)})"
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, durationMs))
            .build()
        return dispatchGesture(g, null, null)
    }

    // ------------------------------------------------------------------ плашки поверх экрана

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(width: Int, gravity: Int, yDp: Int) = WindowManager.LayoutParams(
        width,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT,
    ).apply {
        this.gravity = gravity
        y = dp(yDp)
    }

    /** Запрос разрешения у пользователя. Ждёт нажатия кнопки. */
    suspend fun requestApproval(description: String): Approval = withContext(Dispatchers.Main) {
        val ctx: android.content.Context = this@AgentService
        suspendCancellableCoroutine { cont ->
            val panel = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(12))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#F2202124"))
                    cornerRadius = dp(20).toFloat()
                }
            }
            val title = TextView(ctx).apply {
                text = "Агент хочет выполнить действие:"
                setTextColor(Color.parseColor("#B0B3B8"))
                textSize = 12f
            }
            val body = TextView(ctx).apply {
                text = description
                setTextColor(Color.WHITE)
                textSize = 16f
                setPadding(0, dp(4), 0, dp(10))
            }
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            fun addButton(label: String, result: Approval) {
                val b = Button(ctx).apply {
                    text = label
                    isAllCaps = false
                    setOnClickListener {
                        runCatching { wm.removeView(panel) }
                        if (cont.isActive) cont.resume(result)
                    }
                }
                row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            addButton("Разрешить", Approval.ALLOW)
            addButton("Отказать", Approval.DENY)
            addButton("Стоп", Approval.STOP)
            panel.addView(title)
            panel.addView(body)
            panel.addView(row)
            wm.addView(panel, overlayParams(WindowManager.LayoutParams.MATCH_PARENT, Gravity.BOTTOM, 32).apply {
                horizontalMargin = 0.03f
            })
            cont.invokeOnCancellation { runCatching { wm.removeView(panel) } }
        }
    }

    /** Постоянная кнопка «Стоп» на время работы агента. */
    fun showStopButton(onStop: () -> Unit) {
        hideStopButton()
        val v = TextView(this).apply {
            text = "■ СТОП"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E53935"))
                cornerRadius = dp(20).toFloat()
            }
            setOnClickListener { onStop() }
        }
        stopView = v
        wm.addView(v, overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END, 64).apply {
            x = dp(12)
        })
    }

    fun hideStopButton() {
        stopView?.let { runCatching { wm.removeView(it) } }
        stopView = null
    }
}
